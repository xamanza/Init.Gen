license.md
//////////////////////////////////////
Pd core Copyright (c) by Miller S. Puckette and others 3-clause BSD license
https://github.com/pure-data/pure-data/blob/master/LICENSE.txt
_______________________
Pd-l2ork/purr-data Copyright (c) by Hans-Christoph Steiner, Ico Bukvic, Jonathan Wilkes and others GPL (GNU Public License) version 3
https://github.com/agraef/purr-data/blob/master/LICENSE.md

_______________________
Bundled Software
Copyright (c) by various authors, please see the included license files for details
Init.Gen includes GNRTV.CELLS Toolkit which includes a large number of bundled abstractions and externals by various authors. These can be found in the abstractions, externals and Gem subdirectories in the source, and in the extra subdirectory of the Pd-l2ork library directory of the installed application. Each of these items has its own open-source license under which it is distributed (mostly different variations of the BSD license or the GPL), so please check the corresponding license files in the source or the extra directory of the installed package for license information pertaining to each of the different software modules.

_______________________
Init.Gen Copyright (c) by Xavi Manzanares, and others GPL (GNU Public License) version 3

Also has this specific clause :
-Embed code in hybrid media systems (even those could not be GPL licensed software) is allowed for the following cases:
Artistic, Educational and Research purposes*, independently if those activities are monetized or not.
Those purposes usually means a big work behind it, therefore if further developments includes labor measures of no explotation and human rights accomplishment, it can be used with no restrictions.
Exception : Algorythms generated with CELLS cannot be used for economic speculative monetization dynamics, unless there is a specific consensus with the community of Pd developers and contributors.


Init.Gen
Abril.2024
